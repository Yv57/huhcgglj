<link rel="stylesheet" href="/css/app.css">

<?php
include '../_base.php';

// ----------------------------------------------------------------------------
// Only allow authenticated users
// auth();

$email = $name = $birthofdate = $phoneNo = $address = '';
$photo = 'default.png';

if (is_get()) {
    $stm = $_db->prepare('SELECT email, username, role, photo, phoneNo, birthofdate, address FROM user WHERE user_id = ?');
    $stm->execute([$_user->user_id]);
    $u = $stm->fetch();

    if (!$u) redirect('/');

    // Explicitly assign values (avoid extract)
    $email       = $u->email ?? '';
    $name        = $u->username ?? '';
    $photo       = $u->photo ?? 'default.png';
    $birthofdate = $u->birthofdate ?? '';
    $phoneNo     = $u->phoneNo ?? '';
    $address     = $u->address ?? '';  // Added address

    $_SESSION['photo'] = $photo;
}

if (is_post()) {
    $email       = req('email');
    $name        = req('name');
    $birthofdate = req('birthofdate');
    $phoneNo     = req('phoneNo');
    $address     = req('address');  // Capture address from the form
    $photo       = $_SESSION['photo'];
    $f           = get_file('photo');

    // Email validation
    if ($email == '') {
        $_err['email'] = 'Required';
    } elseif (strlen($email) > 100) {
        $_err['email'] = 'Maximum 100 characters';
    } elseif (!is_email($email)) {
        $_err['email'] = 'Invalid email';
    } else {
        $stm = $_db->prepare('SELECT COUNT(*) FROM user WHERE email = ? AND user_id != ?');
        $stm->execute([$email, $_user->user_id]);
        if ($stm->fetchColumn() > 0) {
            $_err['email'] = 'Duplicated';
        }
    }

    // Name validation
    if ($name == '') {
        $_err['name'] = 'Required';
    } elseif (strlen($name) > 100) {
        $_err['name'] = 'Maximum 100 characters';
    }

    // Birth of date validation
    if (!$birthofdate) {
        $_err['birthofdate'] = 'Required';
    } elseif (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $birthofdate)) {
        $_err['birthofdate'] = 'Invalid format (YYYY-MM-DD)';
    }

    // Phone number validation
    if (!$phoneNo) {
        $_err['phoneNo'] = 'Required';
    } elseif (!preg_match('/^\d{10,15}$/', $phoneNo)) {
        $_err['phoneNo'] = 'Invalid phone number';
    }

    // Address validation (optional)
    if (strlen($address) > 255) {
        $_err['address'] = 'Maximum 255 characters';
    }

    // Photo validation
    if ($f) {
        if (!str_starts_with($f->type, 'image/')) {
            $_err['photo'] = 'Must be an image';
        } elseif ($f->size > 1 * 1024 * 1024) {
            $_err['photo'] = 'Maximum size 1MB';
        }
    }

    // If valid
    if (!$_err) {
        if ($f) {
            if (file_exists("../photos/$photo") && $photo !== 'default.png') {
                unlink("../photos/$photo");
            }
            $photo = save_photo($f, '../photos');
        }

        $stm = $_db->prepare('
            UPDATE user
            SET email = ?, username = ?, birthofdate = ?, phoneNo = ?, address = ?, photo = ?
            WHERE user_id = ?
        ');
        $stm->execute([$email, $name, $birthofdate, $phoneNo, $address, $photo, $_user->user_id]);

        $_user->email = $email;
        $_user->name = $name;
        $_user->photo = $photo;
        $_user->address = $address;  // Update session address

        redirect('/');
    }
}
?>

<!-- Profile Form Container -->
<div class="profile-container">
    <div class="profile-form">
        <h1>Edit Profile</h1>

        <form method="post" class="form" enctype="multipart/form-data">
            <label for="email">Email</label>
            <?= html_text('email', 'value="' . htmlspecialchars($email) . '" maxlength="100" class="input-field"') ?>
            <?= err('email') ?>

            <label for="name">Name</label>
            <?= html_text('name', 'value="' . htmlspecialchars($name) . '" maxlength="100" class="input-field"') ?>
            <?= err('name') ?>

            <label for="phoneNo">Phone Number</label>
            <input type="text" name="phoneNo" value="<?= htmlspecialchars($phoneNo) ?>" maxlength="15" class="input-field">
            <?= err('phoneNo') ?>

            <label for="birthofdate">Birth Date</label>
            <input type="date" name="birthofdate" value="<?= htmlspecialchars($birthofdate) ?>" class="input-field">
            <?= err('birthofdate') ?>

            <label for="address">Address</label>
            <textarea name="address" class="input-field"><?= htmlspecialchars($address) ?></textarea>
            <?= err('address') ?>

            <label for="photo">Photo</label>
            <label class="upload" tabindex="0">
                <?= html_file('photo', 'image/*', 'hidden') ?>
                <img src="/photos/<?= htmlspecialchars($photo) ?>" alt="Profile Photo">
            </label>
            <?= err('photo') ?>

            <section>
                <button type="submit">Submit</button>
                <button type="reset">Reset</button>
            </section>
        </form>
    </div>
</div>
