<link rel="stylesheet" href="/css/app.css">

<?php
include '../_base.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = req('email');
    $password = req('password');
    $confirm  = req('confirm');
    $name     = req('name');
    $phone    = req('phoneNo');
    $birth    = req('birthOfDate');
    $address  = req('address'); // New address field
    $f = get_file('photo');

    // Validate: email
    if (!$email) {
        $_err['email'] = 'Required';
    } else if (strlen($email) > 100) {
        $_err['email'] = 'Maximum 100 characters';
    } else if (strpos($email, '@') === false) {
        $_err['email'] = 'Email must contain @';
    } else if (!is_unique($email, 'user', 'email')) {
        $_err['email'] = 'Duplicated';
    }

    // Validate: password
    if (!$password) {
        $_err['password'] = 'Required';
    } else if (strlen($password) < 5 || strlen($password) > 100) {
        $_err['password'] = 'Between 5-100 characters';
    } else if (!preg_match('/[A-Za-z]/', $password) || !preg_match('/[0-9]/', $password)) {
        $_err['password'] = 'Must contain letters and numbers';
    }

    // Validate: confirm
    if (!$confirm) {
        $_err['confirm'] = 'Required';
    } else if (strlen($confirm) < 5 || strlen($confirm) > 100) {
        $_err['confirm'] = 'Between 5-100 characters';
    } else if ($confirm !== $password) {
        $_err['confirm'] = 'Password does not match';
    }

    // Validate: name
    if (!$name) {
        $_err['name'] = 'Required';
    } else if (strlen($name) > 100) {
        $_err['name'] = 'Maximum 100 characters';
    }

    // Validate: phoneNo
    if (!$phone) {
        $_err['phoneNo'] = 'Required';
    } else if (!preg_match('/^[0-9]{10,15}$/', $phone)) {
        $_err['phoneNo'] = 'Invalid phone number';
    }

    // Validate: BirthOfDate
    if (!$birth) {
        $_err['birthOfDate'] = 'Required';
    } else if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $birth)) {
        $_err['birthOfDate'] = 'Invalid format (YYYY-MM-DD)';
    }

    // Validate: address
    if (!$address) {
        $_err['address'] = 'Required';
    } else if (strlen($address) > 255) {
        $_err['address'] = 'Maximum 255 characters';
    }

    // Validate: photo
    if (!$f) {
        $_err['photo'] = 'Required';
    } else if (!str_starts_with($f->type, 'image/')) {
        $_err['photo'] = 'Must be image';
    } else if ($f->size > 1 * 1024 * 1024) {
        $_err['photo'] = 'Maximum 1MB';
    }

    // DB operation
    if (!$_err) {
        $photo = save_photo($f, '../photos');
        $stm = $_db->prepare('
            INSERT INTO user (email, password, username, phoneNo, birthOfDate, address, photo, role)
            VALUES (?, SHA1(?), ?, ?, ?, ?, ?, "Member")
        ');
        $stm->execute([$email, $password, $name, $phone, $birth, $address, $photo]);

        temp('info', 'Registration successful. Please login.');
        redirect('/login.php');
    }
}

$_title = 'User | Register Member';
?>

<div class="register-container">
    <h1>Register</h1>

    <?php if ($msg = temp('info')): ?>
        <div class="alert success"><?= htmlspecialchars($msg) ?></div>
    <?php endif; ?>

    <form method="post" class="register-form" enctype="multipart/form-data">
        <!-- LEFT COLUMN -->
        <div class="form-column left-column">
            <!-- Existing Fields -->
            <label for="email">Email</label>
            <input type="text" name="email" value="<?= htmlspecialchars($email ?? '') ?>" maxlength="100" class="input-field <?= isset($_err['email']) ? 'input-error' : '' ?>">
            <?= err('email') ?>

            <label for="password">Password</label>
            <?= html_password('password', 'maxlength="100" class="input-field"') ?>
            <?= err('password') ?>

            <label for="confirm">Confirm Password</label>
            <?= html_password('confirm', 'maxlength="100" class="input-field"') ?>
            <?= err('confirm') ?>

            <label for="name">Name</label>
            <?= html_text('name', 'maxlength="100" class="input-field"') ?>
            <?= err('name') ?>

            <label for="phoneNo">Phone Number</label>
            <input type="text" name="phoneNo" value="<?= htmlspecialchars($phone ?? '') ?>" maxlength="15" class="input-field">
            <?= err('phoneNo') ?>

            <!-- New Address Field -->
            <label for="address">Address</label>
            <input type="text" name="address" value="<?= htmlspecialchars($address ?? '') ?>" maxlength="255" class="input-field <?= isset($_err['address']) ? 'input-error' : '' ?>">
            <?= err('address') ?>
        </div>

        <!-- RIGHT COLUMN -->
        <div class="form-column right-column">
            <label for="birthOfDate">Birth Date</label>
            <input type="date" name="birthOfDate" class="input-field" value="<?= htmlspecialchars($birth ?? '') ?>">
            <?= err('birthOfDate') ?>

            <label for="photo">Profile Photo</label>
            <label class="upload" tabindex="0">
                <?= html_file('photo', 'image/*', 'hidden') ?>
                <img src="/images/photo.jpg" alt="Upload Photo">
            </label>
            <?= err('photo') ?>

            <section class="form-buttons">
                <button type="submit">Submit</button>
                <button type="reset">Reset</button>
            </section>
            <a href="/login.php">Have Account ?</a>
        </div>
    </form>
</div>
