<link rel="stylesheet" href="/css/app.css">

<?php
include '../_base.php';

// ----------------------------------------------------------------------------

// Authenticated users
// auth();

if (is_post()) {
    $password     = req('password');
    $new_password = req('new_password');
    $confirm      = req('confirm');

    // Validate: password
    if ($password == '') {
        $_err['password'] = 'Required';
    }
    else if (strlen($password) < 5 || strlen($password) > 100) {
        $_err['password'] = 'Between 5-100 characters';
    }
    else {
        // Verify the current password
        $stm = $_db->prepare('
            SELECT COUNT(*) FROM user
            WHERE password = SHA1(?) AND user_id = ?
        ');
        $stm->execute([$password, $_user->user_id]);

        if ($stm->fetchColumn() == 0) {
            $_err['password'] = 'Incorrect Password';
        }
    }

    // Validate: new_password
    if ($new_password == '') {
        $_err['new_password'] = 'Required';
    }
    else if (strlen($new_password) < 5 || strlen($new_password) > 100) {
        $_err['new_password'] = 'Between 5-100 characters';
    }

    // Validate: confirm
    if (!$confirm) {
        $_err['confirm'] = 'Required';
    }
    else if (strlen($confirm) < 5 || strlen($confirm) > 100) {
        $_err['confirm'] = 'Between 5-100 characters';
    }
    else if ($confirm != $new_password) {
        $_err['confirm'] = 'Not matched';
    }

    // If no validation errors, update the password
    if (!$_err) {
        // Update the password
        $stm = $_db->prepare('
            UPDATE user
            SET password = SHA1(?)
            WHERE user_id = ?
        ');
        $stm->execute([$new_password, $_user->user_id]);

        // Log the user out to ensure they log in with the new password
        session_destroy();  // Destroy the session

        // Redirect to login page after password change
        temp('info', 'Password has been updated. Please log in with your new password.');
        redirect('/login.php');
    }
}

// ----------------------------------------------------------------------------

?>

<!-- Password Change Form Container -->
<div class="profile-container">
    <!-- Form Section -->
    <div class="profile-form">
        <h2>Change Password</h2>

        <!-- Password Form -->
        <form method="post" class="form">
            <!-- Current Password Field -->
            <label for="password">Current Password</label>
            <?= html_password('password', 'maxlength="100" class="input-field"') ?>
            <?= err('password') ?>

            <!-- New Password Field -->
            <label for="new_password">New Password</label>
            <?= html_password('new_password', 'maxlength="100" class="input-field"') ?>
            <?= err('new_password') ?>

            <!-- Confirm Password Field -->
            <label for="confirm">Confirm New Password</label>
            <?= html_password('confirm', 'maxlength="100" class="input-field"') ?>
            <?= err('confirm') ?>

            <!-- Buttons Section -->
            <section>
                <button type="submit">Submit</button>
                <button type="reset">Reset</button>
            </section>
        </form>
    </div>
</div>

