<link rel="stylesheet" href="/css/app.css">

<?php
include '../_base.php';

// ----------------------------------------------------------------------------

// Step 1: Delete expired tokens
$_db->query('DELETE FROM token WHERE expire < NOW()');

// Get token ID from the URL parameter
$id = req('id');

// Fetch the token from the database
$stm = $_db->prepare("SELECT * FROM token WHERE id = ?");
$stm->execute([$id]);
$token = $stm->fetch(PDO::FETCH_OBJ);


// Step 2: Check if the token is valid and not expired
if (!$token || strtotime($token->expire) < time()) {
    temp('info', 'Invalid or expired token. Try again.');
    redirect('/');
}

// Handle POST request when the user submits the new password form
if (is_post()) {
    $password = req('password');
    $confirm  = req('confirm');

    // Validate password
    if ($password == '') {
        $_err['password'] = 'Required';
    }
    else if (strlen($password) < 5 || strlen($password) > 100) {
        $_err['password'] = 'Between 5-100 characters';
    }

    // Validate confirm password
    if ($confirm == '') {
        $_err['confirm'] = 'Required';
    }
    else if (strlen($confirm) < 5 || strlen($confirm) > 100) {
        $_err['confirm'] = 'Between 5-100 characters';
    }
    else if ($confirm != $password) {
        $_err['confirm'] = 'Not matched';
    }

    // If no validation errors, update the password
    if (!$_err) {
    /// Step 3: Update the user's password and delete the token
    $stm = $_db->prepare('
        UPDATE user
        SET password = SHA1(:password)
        WHERE user_id = :user_id;
    ');

        // Bind parameters
        $stm->bindParam(':password', $password, PDO::PARAM_STR);
        $stm->bindParam(':user_id', $token->user_id, PDO::PARAM_INT);

        // Execute the query to update the password
        $stm->execute();

        // After updating the password, delete the token
        $stm = $_db->prepare('DELETE FROM token WHERE id = :token_id');
        $stm->bindParam(':token_id', $id, PDO::PARAM_STR);
        $stm->execute();

        // Notify user of success and redirect
        temp('info', 'Password has been updated.');
        redirect('/index.php');
    }
}

// ----------------------------------------------------------------------------

$_title = 'Reset Password';

?>

<div class="form-container">
    <div class="form-left">
        <h1>Reset Password</h1>
        <form method="post" class="form">
            <label for="password">Password</label>
            <input type="password" name="password" value="<?= htmlspecialchars($password ?? '') ?>" maxlength="100"
                class="input-field <?= isset($_err['password']) ? 'input-error' : '' ?>">
            <?= err('password') ?>

            <label for="confirm">Confirm</label>
            <input type="password" name="confirm" value="<?= htmlspecialchars($confirm ?? '') ?>" maxlength="100"
                class="input-field <?= isset($_err['confirm']) ? 'input-error' : '' ?>">
            <?= err('confirm') ?>

            <section class="form-buttons">
                <button type="submit">Submit</button>
                <button type="reset">Reset</button>
            </section>
        </form>
    </div>
</div>
