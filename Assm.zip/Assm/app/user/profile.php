<?php
include '../_base.php';

// Make sure user is logged in
// auth();

// Load current user info
$stm = $_db->prepare("SELECT email, username, role, photo, phoneNo, birthofdate, address FROM user WHERE user_id = ?");
$stm->execute([$_user->user_id]);
$user = $stm->fetch();

if (!$user) redirect('/');
?>

<?php if ($msg = temp('info')): ?>
    <div class="alert success"><?= htmlspecialchars($msg) ?></div>
<?php endif; ?>

<link rel="stylesheet" href="/css/app.css">

<div class="profile-container">
    <!-- Profile photo and basic info -->
    <div class="profile-photo-section">
        <img src="/photos/<?= htmlspecialchars($user->photo ?? 'default.png') ?>" alt="Profile Photo">
        <h2><?= htmlspecialchars($user->username) ?></h2>
        <p class="user-role"><?= htmlspecialchars($user->role ?? 'Member') ?></p>
    </div>

    <!-- Profile details -->
    <div class="profile-form">
        <h1>Your Profile</h1>
        <div class="form">
            <!-- Email (non-editable) -->
            <label>Email:</label>
            <div class="input-field readonly"><?= htmlspecialchars($user->email) ?></div>

            <!-- Phone Number (non-editable) -->
            <label>Phone Number:</label>
            <div class="input-field readonly"><?= htmlspecialchars($user->phoneNo ?? 'Not Provided') ?></div>

            <!-- Birth Date (non-editable) -->
            <label>Birth Date:</label>
            <div class="input-field readonly"><?= htmlspecialchars($user->birthofdate ?? 'Not Provided') ?></div>

            <!-- Address (non-editable) -->
            <label>Address:</label>
            <div class="input-field readonly"><?= htmlspecialchars($user->address ?? 'Not Provided') ?></div>

            <!-- Button to go edit -->
            <section>
                <a href="edit_profile.php">
                    <button type="button">Edit Profile</button>
                </a>
            </section>
        </div>
    </div>
</div>
