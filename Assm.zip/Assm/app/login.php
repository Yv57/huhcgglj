<link rel="stylesheet" href="/css/app.css">
<?php
include '_base.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = req('email');
    $password = req('password');

    // Validate: email
    if ($email == '') {
        $_err['email'] = 'Required';
    } else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $_err['email'] = 'Invalid email';
    } else if (!is_registered($email)) {
        $_err['email'] = 'Email not registered';
    }

    // Validate: password
    if ($password == '') {
        $_err['password'] = 'Required';
    }

    // Login user
    if (!$_err) {
        $stm = $_db->prepare('
            SELECT * FROM user
            WHERE email = ? AND password = SHA1(?)
        ');
        $stm->execute([$email, $password]);
        $u = $stm->fetch();

        if ($u) {
            temp('info', 'Login successfully');
            login($u);
            redirect('/profile.php');
        } else {
            $_err['password'] = 'Incorrect password';
        }
    }
}

$_title = 'Login';
?>

<?php if ($msg = temp('info')): ?>
    <div class="alert success"><?= htmlspecialchars($msg) ?></div>
<?php endif; ?>

<div class="form-container">
    <div class="form-left">
        <h1>Login</h1>
        <form method="post" class="form">
            <label for="email">Email</label>
            <input type="text" name="email" value="<?= htmlspecialchars($email ?? '') ?>" maxlength="100"
                class="input-field <?= isset($_err['email']) ? 'input-error' : '' ?>">
            <?= err('email') ?>

            <label for="password">Password</label>
            <input type="password" name="password" maxlength="100"
                class="input-field <?= isset($_err['password']) ? 'input-error' : '' ?>">
            <?= err('password') ?>

            <a href="/user/reset.php">Forgot Password?</a>

            <section class="form-buttons">
                <button type="submit">Login</button>
                <button type="reset">Reset</button>
            </section>
        </form>
    </div>
</div>
