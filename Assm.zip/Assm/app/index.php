<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $_title ?? 'Untitled' ?></title>
    <link rel="shortcut icon" href="/images/favicon.png">
    <link rel="stylesheet" href="/css/app.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="/js/app.js"></script>
</head>

<?php
require '_base.php';
//-----------------------------------------------------------------------------



// ----------------------------------------------------------------------------
$_title = 'Index';
//include '_head.php';
?>
    <?php if ($msg = temp('info')): ?>
        <div class="alert success"><?= htmlspecialchars($msg) ?></div>
    <?php endif; ?>

    
    <?php if ($_user): ?>
        <a href="/user/profile.php">Profile</a>
        <a href="/user/password.php">Password</a>
        <a href="/logout.php">Logout</a>
    <?php else: ?>
        <a href="/user/register.php">Register</a>
        <a href="/login.php">Login</a>
    <?php endif ?>


<?php
//include '_foot.php';