<?php
require '../config/db.php';
session_start();

$order_id = $_GET['id'] ?? null;
$user_id = $_SESSION['user_id'];

$stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ? AND user_id = ? AND status = 'Pending'");
$stmt->execute([$order_id, $user_id]);
$order = $stmt->fetch();

if (!$order) {
    die("Order cannot be cancelled.");
}

$stmt = $pdo->prepare("UPDATE orders SET status = 'Cancelled' WHERE id = ?");
$stmt->execute([$order_id]);

echo "Order cancelled successfully.";
?>
