<?php
session_start();
require 'db_connect.php';

// Get order ID from URL
if (!isset($_GET['order_id'])) {
    header("Location: order_history.php");
    exit();
}

$order_id = $_GET['order_id'];

// Fetch order details
$stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ?");
$stmt->execute([$order_id]);
$order = $stmt->fetch(PDO::FETCH_ASSOC);

// Fetch products in the order
$stmt = $pdo->prepare("SELECT oi.*, p.name, p.price 
                       FROM order_items oi
                       JOIN products p ON oi.product_id = p.id
                       WHERE oi.order_id = ?");
$stmt->execute([$order_id]);
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Details</title>
</head>
<body>
    <h2>Order Details (Order ID: <?= $order['id'] ?>)</h2>
    <p><strong>Status:</strong> <?= $order['status'] ?></p>
    <p><strong>Total Price:</strong> $<?= $order['total_price'] ?></p>

    <h3>Products in Order</h3>
    <table border="1">
        <tr>
            <th>Product</th>
            <th>Quantity</th>
            <th>Price</th>
        </tr>
        <?php foreach ($items as $item): ?>
            <tr>
                <td><?= $item['name'] ?></td>
                <td><?= $item['quantity'] ?></td>
                <td>$<?= $item['price'] ?></td>
            </tr>
        <?php endforeach; ?>
    </table>

    <a href="<?= $_SESSION['role'] == 'admin' ? 'admin_orders.php' : 'order_history.php' ?>">Back</a>
</body>
</html>
