<?php 
    session_start(); 
    include 'includes/header.php'; 
?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
<script src="script.js?v=1.0"></script>

<!-- Navigation Bar -->
<nav class="navbar">
    <div class="logo">
        <a href="index.php">🎁 Blind Box Shop</a>
    </div>
    <ul class="nav-links">
        <li><a href="index.php">Home</a></li>
        <li><a href="shop.php">Shop</a></li>
        <li><a href="about.php">About Us</a></li>
        <li><a href="login.php">Login</a></li>
    </ul>
</nav>

<!-- GIF Blind Box Popup -->
<div id="blindBoxPopup" class="popup-container">
    <div class="popup-content">
        <h2>🎁 Welcome! Open Your Blind Box!</h2><br>
        <p>Claiim the reward to reveal your reward!</p>
        <img id="blindBoxGif" src="images/giftbox.gif" alt="Blind Box Animation">
        <h2 id="rewardText" class="hidden"></h2>
        <button id="claimReward" class="hidden btn">Claim Reward</button>
    </div>
</div>

<!-- Slideshow Section -->
<section class="swiper-container">
    <div class="swiper-wrapper">
        <div class="swiper-slide"><img src="images/b6.jpg" alt="Seasonal Box"></div>
        <div class="swiper-slide"><img src="images/b4.jpg" alt="Limited Edition"></div>
        <div class="swiper-slide"><img src="images/b10.jpg" alt="Mystery Box"></div>
    </div>
    <div class="swiper-pagination"></div>
    <div class="swiper-button-next"></div>
    <div class="swiper-button-prev"></div>
</section>

<div class="product-list">
        <div class="product-item">
            <img src="images/molly2.jpg" alt="Leather Bracelet">
            <p>Leather Bracelet</p>
        </div>
        <div class="product-item">
            <img src="images/dimoo.jpg" alt="Safety Chains">
            <p>Safety Chains</p>
        </div>
        <div class="product-item">
            <img src="images/crybaby.jpg" alt="Glass Beads">
            <p>Glass Beads</p>
        </div>
        <div class="product-item">
            <img src="images/panda.jpg" alt="Charms">
            <p>Charms</p>
        </div>
        <div class="product-item">
            <img src="images/hacipupu.jpg" alt="Charms">
            <p>Charms</p>
        </div>
    
    </div>

<!-- 🌟 Full-width Banner with Text on the Left -->
<section class="promo-banner">
  <div class="promo-content">
    <h2>🌟 Limited Edition Boxes</h2>
    <p>Discover rare seasonal treasures only available for a short time. Perfect for gifting or collecting!</p>
    <a href="#" class="promo-btn">Explore Now</a>
  </div>
</section>


<section class="collection">
<h4>FEATURED COLLECTION</h4><br>
    <div class="grid-container">
      <?php
      $collections = [
        [
          'title' => 'CHARMS',
          'image' => 'images/f1.jpg',
          'link'  => '#',
          'class' => 'charms'
        ],
        [
          'title' => 'BRACELETS',
          'image' => 'images/f4.jpg',
          'link'  => '#',
          'class' => 'bracelets'
        ],
        [
          'title' => 'JEWELRY',
          'image' => 'images/f3.jpg',
          'link'  => '#',
          'class' => 'jewelry'
        ],
        [
          'title' => 'MURANO GLASS',
          'image' => 'images/f7.jpg',
          'link'  => '#',
          'class' => 'murano'
        ]
      ];

      // Loop through each item
      foreach ($collections as $item) {
        echo '
        <div class="grid-item ' . $item['class'] . '">
          <img src="' . $item['image'] . '" alt="' . $item['title'] . '">
          <div class="overlay">
            <h3>' . $item['title'] . '</h3>
            <a href="' . $item['link'] . '" class="grid-btn">Learn More</a>
          </div>
        </div>';
      }
      ?>
    </div>
  </section>

  <section class="service-section">
  <div class="service-container">
    <?php
    $services = [
      ['icon' => 'img/icons/delivery.png', 'title' => 'Delivery', 'desc' => '100% Secure'],
      ['icon' => 'img/icons/payment.png', 'title' => 'Payment', 'desc' => '100% Secure'],
      ['icon' => 'img/icons/support.png', 'title' => 'Support', 'desc' => '24*7 Hours'],
      ['icon' => 'img/icons/gift.png', 'title' => 'Gift Service', 'desc' => 'Support Gift Service'],
      ['icon' => 'img/icons/returns.png', 'title' => 'Returns', 'desc' => '24*7 Free Returns'],
      ['icon' => 'img/icons/moneyback.png', 'title' => 'Money Back', 'desc' => '100% Secure']
    ];

    foreach ($services as $service) {
      echo '
      <div class="service-card">
        <div class="service-icon">
          <img src="' . $service['icon'] . '" alt="' . htmlspecialchars($service['title']) . ' Icon">
        </div>
        <div class="service-content">
          <h4>' . htmlspecialchars($service['title']) . '</h4>
          <p>' . htmlspecialchars($service['desc']) . '</p>
        </div>
      </div>';
    }
    ?>
  </div>
</section>



<!-- 关于我们 (About Us) -->
<section class="about-us">
    <h2>💖 关于我们</h2>
    <p>我们是一家专注于盲盒文化的品牌，为你带来最有趣的拆箱体验！从经典系列到最新潮流，每个盲盒都是一个惊喜！</p>
</section>

<?php include 'includes/footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>
<script src="js/script.js"></script>
</body>
</html>
