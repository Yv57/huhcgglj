document.addEventListener("DOMContentLoaded", function () {
    var swiper = new Swiper(".swiper-container", {
        loop: true,
        autoplay: {
            delay: 3000,
            disableOnInteraction: false,
        },
        pagination: {
            el: ".swiper-pagination",
            clickable: true,
        },
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
    });
});

document.addEventListener("DOMContentLoaded", function() {
    const blindBoxPopup = document.getElementById("blindBoxPopup");
    const rewardText = document.getElementById("rewardText");
    const claimReward = document.getElementById("claimReward");

    // Rewards
    const rewards = ["10% Off Coupon!", "Free Shipping!", "$5 Discount!"];
    const selectedReward = rewards[Math.floor(Math.random() * rewards.length)];

    // Show popup after 1 second
    setTimeout(() => {
        blindBoxPopup.classList.add("active");
    }, 1000);

    // Open Box Animation (When user clicks the GIF)
    const blindBoxGif = document.getElementById("blindBoxGif");
    blindBoxGif.addEventListener("click", function() {
        setTimeout(() => {
            rewardText.innerText = `🎉 You won: ${selectedReward}`;
            rewardText.classList.remove("hidden");
            claimReward.classList.remove("hidden");
        }, 500); // Delay for effect
    });

    // Claim Reward Button Clicked
    claimReward.addEventListener("click", function() {
        blindBoxPopup.classList.remove("active");  // Close the popup
        document.cookie = `userReward=${selectedReward}; path=/;`;
    });
});

