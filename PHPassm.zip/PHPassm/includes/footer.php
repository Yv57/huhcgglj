<footer>
    <p>&copy; <?php echo date('Y'); ?> Blind Box Store. All rights reserved.</p>
</footer>
