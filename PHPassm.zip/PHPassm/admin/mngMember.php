<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "assignment_db";

// Connect to the database
$conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle delete request
if (isset($_GET['delete_id'])) {
    $user_id = intval($_GET['delete_id']);
    $delete_sql = "DELETE FROM users WHERE user_id = $user_id";
    
    if ($conn->query($delete_sql)) {
        echo "<script>alert('Member deleted successfully!'); window.location='mngMember.php';</script>";
    } else {
        echo "<script>alert('Failed to delete member!'); window.location='mngMember.php';</script>";
    }
}

// Search Functionality
$search = "";
if (isset($_GET['search'])) {
    $search = trim($_GET['search']);
    $sql = "SELECT * FROM users WHERE 
            username LIKE ? OR 
            email LIKE ? OR 
            full_name LIKE ? OR 
            address LIKE ?";
    $stmt = $conn->prepare($sql);
    $search_param = "%$search%";
    $stmt->bind_param("ssss", $search_param, $search_param, $search_param, $search_param);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $sql = "SELECT * FROM users";
    $result = $conn->query($sql);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Members</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: #f8f9fa;
        }
        h2 {
            text-align: center;
            color: #333;
        }
        .search-container {
            text-align: center;
            margin-bottom: 20px;
        }
        input[type="text"] {
            padding: 8px;
            width: 300px;
            border: 1px solid #ccc;
            border-radius: 5px;
            outline: none;
        }
        button {
            padding: 8px 15px;
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            transition: 0.3s;
        }
        button:hover {
            background-color: #0056b3;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: white;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            overflow: hidden;
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: center;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #e9ecef;
        }
        img {
            width: 50px;
            height: 50px;
            border-radius: 50%;
        }
        .update-btn {
    padding: 5px 10px;
    background-color: #28a745;
    color: white;
    text-decoration: none;
    border-radius: 5px;
    margin-left: 5px;
    transition: 0.3s;
}
.update-btn:hover {
    background-color: #218838;
}

        .delete-btn {
            padding: 5px 10px;
            background-color: #dc3545;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            transition: 0.3s;
        }
        .delete-btn:hover {
            background-color: #c82333;
        }
        @media (max-width: 600px) {
            table, th, td {
                font-size: 14px;
            }
            input[type="text"] {
                width: 80%;
            }
        }
    </style>
    <script>
        function confirmDelete(userId) {
            if (confirm("Are you sure you want to delete this member?")) {
                window.location.href = "mngMember.php?delete_id=" + userId;
            }
        }
    </script>
</head>
<body>

<h1>Admin Dashboard - Manage Members</h1>
    <nav>
        <a href="admin_dashboard.php">Dashboard</a>
        <a href="mngMember.php">User Management</a>
        <a href="ProdManagement.php">Products Management</a>
        <a href="orders.php">Orders</a>
        <a href="logout.php">Logout</a>
    </nav>

<!-- Search Form -->
<div class="search-container">
    <form method="GET" action="mngMember.php">
        <input type="text" name="search" placeholder="Search by name, email, address..." value="<?php echo htmlspecialchars($search); ?>">
        <button type="submit">Search</button>
    </form>
</div>

<table>
    <tr>
        <th>ID</th>
        <th>Username</th>
        <th>Email</th>
        <th>Full Name</th>
        <th>Address</th>
        <th>Joined Date</th>
        <th>Profile Photo</th>
        <th>Action</th>
    </tr>

    <?php
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['user_id']; ?></td>
                <td><?php echo htmlspecialchars($row['username']); ?></td>
                <td><?php echo htmlspecialchars($row['email']); ?></td>
                <td><?php echo htmlspecialchars($row['full_name'] . " " . $row['last_name']); ?></td>
                <td><?php echo htmlspecialchars($row['address']); ?></td>
                <td><?php echo $row['created_at']; ?></td>
                <td>
                    <?php if (!empty($row['ProfilePhoto'])): ?>
                        <img src="data:image/jpeg;base64,<?php echo base64_encode($row['ProfilePhoto']); ?>" />
                    <?php else: ?>
                        No Photo
                    <?php endif; ?>
                </td>
                <td>
                <button class="delete-btn" onclick="confirmDelete(<?php echo $row['user_id']; ?>)">Delete</button>
                <a href="updateMember.php?user_id=<?php echo $row['user_id']; ?>" class="update-btn">Update</a>
                <td>
</td>

                </td>
            </tr>
        <?php endwhile;
    } else {
        echo "<tr><td colspan='8'>No members found.</td></tr>";
    }
    ?>
</table>

</body>
</html>

<?php
$conn->close();
?>
