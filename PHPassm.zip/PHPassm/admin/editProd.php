<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "assignment_db";

$conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$product_id = isset($_GET['product_id']) ? intval($_GET['product_id']) : 0;
if ($product_id === 0) {
    die("Product ID not provided.");
}

// Fetch product details
$product_query = "SELECT * FROM products WHERE product_id = ?";
$stmt = $conn->prepare($product_query);
$stmt->bind_param("i", $product_id);
$stmt->execute();
$product_result = $stmt->get_result();
$product = $product_result->fetch_assoc();

if (!$product) {
    die("Product not found.");
}

// Fetch images
$image_query = "SELECT image_id, image FROM prod_details WHERE product_id = ?";
$stmt = $conn->prepare($image_query);
$stmt->bind_param("i", $product_id);
$stmt->execute();
$images_result = $stmt->get_result();

// Fetch prices
$price_query = "SELECT uom, price FROM product_price WHERE product_id = ?";
$stmt = $conn->prepare($price_query);
$stmt->bind_param("i", $product_id);
$stmt->execute();
$price_result = $stmt->get_result();

$price_each = 0;
$price_whole = 0;
while ($row = $price_result->fetch_assoc()) {
    if ($row['uom'] === 'box') {
        $price_each = $row['price'];
    } elseif ($row['uom'] === 'whole_box') {
        $price_whole = $row['price'];
    }
}

// Delete images
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_images'])) {
    foreach ($_POST['delete_images'] as $image_id) {
        $delete_query = "DELETE FROM prod_details WHERE image_id = ?";
        $stmt = $conn->prepare($delete_query);
        $stmt->bind_param("i", $image_id);
        $stmt->execute();
    }
    header("Location: ".$_SERVER['PHP_SELF']."?product_id=".$product_id);
    exit();
}

// Update product info
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_product'])) {
    $name = $_POST['name'];
    $price_each = $_POST['price_each'];
    $price_whole = $_POST['price_whole'];
    $stock = $_POST['stock'];

    // Update product
    $update_product_query = "UPDATE products SET name=?, stock=? WHERE product_id=?";
    $stmt = $conn->prepare($update_product_query);
    $stmt->bind_param("sii", $name, $stock, $product_id);
    $stmt->execute();

    // Update prices
    $update_price_query = "UPDATE product_price SET price=? WHERE product_id=? AND uom=?";
    
    // Fix: Bind literal strings instead of variables
    $stmt = $conn->prepare($update_price_query);
    $uom1 = 'box';
$stmt->bind_param("dis", $price_each, $product_id, $uom1);
    $stmt->execute();
    $stmt = $conn->prepare($update_price_query);
    $uom2 = 'whole_box';
$stmt->bind_param("dis", $price_whole, $product_id, $uom2);

    $stmt->execute();

    header("Location: ".$_SERVER['PHP_SELF']."?product_id=".$product_id);
    exit();
}

// Upload images
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES['new_images'])) {
    foreach ($_FILES['new_images']['tmp_name'] as $key => $tmp_name) {
        if (!empty($tmp_name)) {
            $image_data = file_get_contents($tmp_name);
            $insert_image_query = "INSERT INTO prod_details (product_id, image) VALUES (?, ?)";
            $stmt = $conn->prepare($insert_image_query);
            $stmt->bind_param("ib", $product_id, $null);
            $stmt->send_long_data(1, $image_data);
            $stmt->execute();
        }
    }
    header("Location: ".$_SERVER['PHP_SELF']."?product_id=".$product_id);
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Product</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f4f6f8;
            color: #333;
        }
        .container {
            width: 600px;
            margin: 30px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        h2 {
            color: #333;
            margin-bottom: 20px;
        }
        label {
            text-align: left;
            display: block;
            margin-top: 10px;
            font-weight: bold;
        }
        input[type="text"],
        input[type="number"],
        input[type="file"],
        button {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 15px;
        }
        button {
            background-color: #1e90ff;
            color: white;
            font-weight: bold;
            margin-top: 15px;
            cursor: pointer;
            transition: 0.3s ease;
        }
        button:hover {
            background-color: #0b74d4;
        }
        .image-box {
            display: inline-block;
            margin: 10px;
            text-align: center;
        }
        .image-box img {
            width: 100px;
            height: 100px;
            border-radius: 5px;
            object-fit: cover;
            display: block;
            margin-bottom: 5px;
        }
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #1e90ff;
            text-decoration: none;
        }
        .back-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Edit Product</h2>
    <a href="ProdManagement.php" class="back-link">← Back to Product List</a>

    <form action="" method="post">
        <label>Product Name:</label>
        <input type="text" name="name" value="<?php echo htmlspecialchars($product['name']); ?>" required>

        <label>Price per Box (RM):</label>
        <input type="number" name="price_each" step="0.01" value="<?php echo $price_each; ?>" required>

        <label>Price per Whole Box (RM):</label>
        <input type="number" name="price_whole" step="0.01" value="<?php echo $price_whole; ?>" required>

        <label>Stock:</label>
        <input type="number" name="stock" value="<?php echo $product['stock']; ?>" required>

        <button type="submit" name="update_product">Update Product</button>
    </form>

    <h3>Current Images:</h3>
    <form action="" method="post">
        <?php $images_result->data_seek(0); // Reset result pointer ?>
        <?php while ($image = $images_result->fetch_assoc()): ?>
            <div class="image-box">
                <img src="data:image/jpeg;base64,<?php echo base64_encode($image['image']); ?>" alt="Product Image">
                <input type="checkbox" name="delete_images[]" value="<?php echo $image['image_id']; ?>">
            </div>
        <?php endwhile; ?>
        <button type="submit">Delete Selected Images</button>
    </form>

    <h3>Upload New Images:</h3>
    <form action="" method="post" enctype="multipart/form-data">
        <input type="file" name="new_images[]" multiple>
        <button type="submit">Upload Images</button>
    </form>
</div>

</body>
</html>

<?php $conn->close(); ?>
