<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "assignment_db";

$conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle batch deletion
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_selected'])) {
    $selected_ids = $_POST['product_ids'] ?? [];

    if (!empty($selected_ids)) {
        $placeholders = implode(',', array_fill(0, count($selected_ids), '?'));
        $types = str_repeat('i', count($selected_ids));

        // Delete from prod_details
        $stmt = $conn->prepare("DELETE FROM prod_details WHERE product_id IN ($placeholders)");
        $stmt->bind_param($types, ...$selected_ids);
        $stmt->execute();

        // Delete from product_price
        $stmt = $conn->prepare("DELETE FROM product_price WHERE product_id IN ($placeholders)");
        $stmt->bind_param($types, ...$selected_ids);
        $stmt->execute();

        // Delete from products
        $stmt = $conn->prepare("DELETE FROM products WHERE product_id IN ($placeholders)");
        $stmt->bind_param($types, ...$selected_ids);
        if ($stmt->execute()) {
            echo "<script>alert('Product(s) deleted successfully!'); window.location='ProdManagement.php';</script>";
        } else {
            echo "<script>alert('Error deleting product.');</script>";
        }
    }
}

// Highlight function
function highlight($text, $search) {
    if (!$search) return htmlspecialchars($text);
    return preg_replace('/(' . preg_quote($search, '/') . ')/i', '<mark>$1</mark>', htmlspecialchars($text));
}

// Product name search only
$search = $_GET['search'] ?? "";
$sql = "SELECT p.product_id, p.name, p.description, pp_single.price AS single_price, pp_whole.price AS whole_price, p.stock 
        FROM products p 
        LEFT JOIN product_price pp_single ON p.product_id = pp_single.product_id AND pp_single.uom = 'box'
        LEFT JOIN product_price pp_whole ON p.product_id = pp_whole.product_id AND pp_whole.uom = 'whole_box'
        WHERE p.name LIKE ?";
$stmt = $conn->prepare($sql);
$search_param = "%" . $search . "%";
$stmt->bind_param("s", $search_param);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Products</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        nav a {
            margin-right: 15px;
            text-decoration: none;
            background: #333;
            color: white;
            padding: 8px 15px;
            border-radius: 5px;
        }
        nav a:hover { background-color: #555; }
        .button-container {
            display: flex;
            justify-content: space-between;
            margin: 15px 0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: center;
        }
        th { background-color: #007bff; color: white; }
        img {
            width: 80px;
            height: auto;
            margin: 5px;
        }
        .edit-btn {
            padding: 5px 10px;
            background-color: #007bff;
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }
        .edit-btn:hover { background-color: #0056b3; }
        .reset-btn {
            padding: 6px 12px;
            background-color: #6c757d;
            color: white;
            text-decoration: none;
            border-radius: 4px;
        }
        mark { background-color: yellow; }
    </style>
    <script>
        function confirmBatchDelete() {
            return confirm("Are you sure you want to delete the selected products?");
        }
    </script>
</head>
<body>

<h1>Admin Dashboard - Manage Products</h1>

<nav>
    <a href="admin_dashboard.php">Dashboard</a>
    <a href="mngMember.php">User Management</a>
    <a href="ProdManagement.php">Products Management</a>
    <a href="orders.php">Orders</a>
    <a href="logout.php">Logout</a>
</nav>

<!-- Search Form -->
<form method="GET" action="" style="margin: 20px 0;">
    <input type="text" name="search" placeholder="Search by product name..." value="<?php echo htmlspecialchars($search); ?>">
    <button type="submit">Search</button>
    <a href="ProdManagement.php" class="reset-btn">Reset</a>
</form>

<form method="POST" action="ProdManagement.php" onsubmit="return confirmBatchDelete();">
    <div class="button-container">
        <a href="addProd.php" class="edit-btn">Create Product</a>
        <button type="submit" name="delete_selected" class="edit-btn" style="background-color: #dc3545;">Delete Selected</button>
    </div>

    <table>
        <tr>
            <th>Select</th>
            <th>ID</th>
            <th>Name</th>
            <th>Description</th>
            <th>Single Price (RM)</th>
            <th>Whole Box Price (RM)</th>
            <th>Stock</th>
            <th>Images</th>
            <th>Actions</th>
        </tr>

        <?php while ($row = $result->fetch_assoc()): ?>
            <tr id="row-<?php echo $row['product_id']; ?>">
                <td><input type="checkbox" name="product_ids[]" value="<?php echo $row['product_id']; ?>"></td>
                <td><?php echo $row['product_id']; ?></td>
                <td><?php echo highlight($row['name'], $search); ?></td>
                <td><?php echo htmlspecialchars($row['description']); ?></td>
                <td><?php echo $row['single_price'] ?: 'N/A'; ?></td>
                <td><?php echo $row['whole_price'] ?: 'N/A'; ?></td>
                <td><?php echo $row['stock']; ?></td>
                <td>
                    <?php
                    $img_stmt = $conn->prepare("SELECT image FROM prod_details WHERE product_id = ?");
                    $img_stmt->bind_param("i", $row['product_id']);
                    $img_stmt->execute();
                    $img_result = $img_stmt->get_result();
                    while ($img_row = $img_result->fetch_assoc()) {
                        if (!empty($img_row['image'])) {
                            echo '<img src="data:image/jpeg;base64,' . base64_encode($img_row['image']) . '" />';
                        }
                    }
                    ?>
                </td>
                <td>
                    <a href="editProd.php?product_id=<?php echo $row['product_id']; ?>" class="edit-btn">Edit</a>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>
</form>

</body>
</html>

<?php
$conn->close();
?>
