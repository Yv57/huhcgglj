<?php
require '../assignment_db.php'; 

$order_id = $_GET['id'] ?? null;
if (!$order_id) {
    die("Order ID is required.");
}

$stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ?");
$stmt->execute([$order_id]);
$order = $stmt->fetch();

if (!$order) {
    die("Order not found.");
}
?>

<h2>Order Details</h2>
<p>Order ID: <?= $order['id'] ?></p>
<p>Status: <?= $order['status'] ?></p>
<p>Total Price: <?= $order['total_price'] ?></p>
<!-- Add more order details here -->
