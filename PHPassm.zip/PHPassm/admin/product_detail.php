<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "assignment_db";

$conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (!isset($_GET['product_id']) || empty($_GET['product_id'])) {
    die("Product ID is missing.");
}

$product_id = intval($_GET['product_id']); // Prevent SQL Injection

$query = "SELECT * FROM products WHERE product_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $product_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Product not found.");
}

$product = $result->fetch_assoc();

// Fetch all images for the product
$image_query = "SELECT image FROM prod_details WHERE product_id = ?";
$stmt = $conn->prepare($image_query);
$stmt->bind_param("i", $product_id);
$stmt->execute();
$image_result = $stmt->get_result();
$images = [];

while ($row = $image_result->fetch_assoc()) {
    $images[] = base64_encode($row['image']); // Convert to base64 for display
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($product['name']); ?></title>
</head>
<body>
    <h1><?php echo htmlspecialchars($product['name']); ?></h1>
    <p><?php echo nl2br(htmlspecialchars($product['description'])); ?></p>
    <p>Price: RM <?php echo number_format($product['price'], 2); ?></p>

    <h2>Product Images</h2>
    <?php if (!empty($images)): ?>
        <?php foreach ($images as $image): ?>
            <img src="data:image/jpeg;base64,<?php echo $image; ?>" width="200">
        <?php endforeach; ?>
    <?php else: ?>
        <p>No images available.</p>
    <?php endif; ?>
</body>
</html>
