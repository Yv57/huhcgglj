<?php
// Database connection
$host = "localhost";
$username = "root";
$password = "";
$database = "assignment_db";

$conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all products
$productQuery = "SELECT product_id, name, description, price, stock FROM products";
$productResult = $conn->query($productQuery);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Products</title>
</head>
<body>
    <h2>Product List</h2>
    <?php
    if ($productResult->num_rows > 0) {
        while ($product = $productResult->fetch_assoc()) {
            echo "<div style='border: 1px solid #ccc; padding: 10px; margin-bottom: 20px;'>";
            echo "<h3>" . htmlspecialchars($product['name']) . "</h3>";
            echo "<p><strong>Description:</strong> " . nl2br(htmlspecialchars($product['description'])) . "</p>";
            echo "<p><strong>Price:</strong> $" . number_format($product['price'], 2) . "</p>";
            echo "<p><strong>Stock:</strong> " . $product['stock'] . "</p>";

            // Fetch product images
            $product_id = $product['product_id'];
            $imgStmt = $conn->prepare("SELECT image FROM prod_details WHERE product_id = ?");
            $imgStmt->bind_param("i", $product_id);
            $imgStmt->execute();
            $imgStmt->store_result();
            
            echo "<h4>Product Images:</h4>";
            if ($imgStmt->num_rows > 0) {
                $imgStmt->bind_result($image);
                while ($imgStmt->fetch()) {
                    echo '<img src="data:image/jpeg;base64,' . base64_encode($image) . '" width="150" height="150" style="margin:5px;">';
                }
            } else {
                echo "<p>No images available for this product.</p>";
            }
            $imgStmt->close();
            echo "</div>";
        }
    } else {
        echo "<p>No products found.</p>";
    }

    $conn->close();
    ?>
</body>
</html>
