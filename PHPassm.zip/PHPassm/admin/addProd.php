<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "assignment_db";

$conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$errors = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $price_each = trim($_POST['single_price']);
    $price_whole = trim($_POST['whole_price']);    
    $stock = trim($_POST['stock']);
    $main_image_index = isset($_POST['main_image_index']) ? intval($_POST['main_image_index']) : 0;

    // ** Validate Required Fields **
    if (empty($name)) $errors['name'] = "Product name is required.";
    if (empty($description)) $errors['description'] = "Description is required.";
    if (!is_numeric($price_each) || floatval($price_each) <= 0) $errors['price_each'] = "Price for each box must be a positive number.";
    if (!is_numeric($price_whole) || floatval($price_whole) <= 0) $errors['price_whole'] = "Price for whole box must be a positive number.";
    if (!is_numeric($stock) || intval($stock) < 0) $errors['stock'] = "Stock must be a non-negative integer.";

    // ** Validate Images **
    $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
    $maxFileSize = 5 * 1024 * 1024; // 5MB
    if (empty($_FILES['images']['name'][0])) {
        $errors['images'] = "At least one image is required.";
    }

    if (empty($errors)) {
        $stmt = $conn->prepare("INSERT INTO products (name, description, stock) VALUES (?, ?, ?)");
        if (!$stmt) die("Error preparing product query: " . $conn->error);
        $stmt->bind_param("ssi", $name, $description, $stock);
        
        if ($stmt->execute()) {
            $product_id = $stmt->insert_id;

            // Insert prices into product_price table
            $priceStmt = $conn->prepare("INSERT INTO product_price (product_id, price, uom) VALUES (?, ?, ?), (?, ?, ?)");
            if (!$priceStmt) die("Error preparing price query: " . $conn->error);
            $uom1 = 'box';
            $uom2 = 'whole_box';
            $priceStmt->bind_param("idsids", $product_id, $price_each, $uom1, $product_id, $price_whole, $uom2);
            $priceStmt->execute();
            $priceStmt->close();

            // Insert images
            foreach ($_FILES['images']['tmp_name'] as $key => $tmp_name) {
                if ($_FILES['images']['error'][$key] == 0) {
                    $imageData = file_get_contents($tmp_name);
                    $is_main = ($key == $main_image_index) ? 1 : 0;

                    $imgStmt = $conn->prepare("INSERT INTO prod_details (product_id, image, is_main) VALUES (?, ?, ?)");
                    if (!$imgStmt) die("Error preparing image query: " . $conn->error);

                    $imgStmt->bind_param("isi", $product_id, $imageData, $is_main);
                    $imgStmt->send_long_data(1, $imageData);
                    $imgStmt->execute();
                    $imgStmt->close();
                }
            }
            echo "<p style='color: green;'>Product and images added successfully!</p>";
        } else {
            echo "<p style='color: red;'>Error: " . $stmt->error . "</p>";
        }
        $stmt->close();
    }
}
$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Product</title>
    <link rel="stylesheet" href="admin.css"> 
    <style>
        .error { color: red; font-size: 14px; }
        .preview-container {
            display: flex;
            gap: 10px;
            margin-top: 10px;
        }
        .preview-container img {
            width: 100px;
            height: 100px;
            object-fit: cover;
            border: 1px solid #ddd;
            padding: 5px;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Add Product</h2>
    <a href="ProdManagement.php">Back to Products</a>

    <form name="productForm" action="addProd.php" method="post" enctype="multipart/form-data" onsubmit="return validateForm();">
        <label>Name:</label><br>
        <input type="text" name="name" id="name"><span class="error" id="nameError"></span><br><br>

        <label>Description:</label><br>
        <textarea name="description" id="description"></textarea><span class="error" id="descriptionError"></span><br><br>

        <label>Stock:</label><br>
        <input type="number" name="stock" id="stock"><span class="error" id="stockError"></span><br><br>

        <label>Single Box Price:</label><br>
        <input type="number" name="single_price" id="single_price" step="0.01"><span class="error" id="singlePriceError"></span><br><br>

        <label>Whole Box Price:</label><br>
        <input type="number" name="whole_price" id="whole_price" step="0.01"><span class="error" id="wholePriceError"></span><br><br>

        <label>Upload Images:</label><br>
        <input type="file" name="images[]" id="images" accept="image/*" multiple onchange="previewImages();"><span class="error" id="imageError"></span><br>
        <div class="preview-container" id="imagePreview"></div><br>
        
        <label>Select Main Image:</label>
        <select name="main_image_index">
            <option value="0">First Image</option>
            <option value="1">Second Image</option>
            <option value="2">Third Image</option>
            <option value="3">Fourth Image</option>
            <option value="4">Fifth Image</option>
        </select>

        <input type="submit" value="Add Product">
    </form>
</div>

<script>
    function validateForm() {
        let valid = true;
        document.querySelectorAll(".error").forEach(el => el.textContent = "");

        let name = document.forms["productForm"]["name"].value.trim();
        let description = document.forms["productForm"]["description"].value.trim();
        let stock = document.forms["productForm"]["stock"].value.trim();
        let singlePrice = document.forms["productForm"]["single_price"].value.trim();
        let wholePrice = document.forms["productForm"]["whole_price"].value.trim();
        let images = document.forms["productForm"]["images"].files;

        if (name === "") {
            document.getElementById("nameError").textContent = "Name is required.";
            valid = false;
        }
        if (description === "") {
            document.getElementById("descriptionError").textContent = "Description is required.";
            valid = false;
        }
        if (stock === "" || parseInt(stock) < 0) {
            document.getElementById("stockError").textContent = "Stock must be non-negative.";
            valid = false;
        }
        if (singlePrice === "" || parseFloat(singlePrice) <= 0) {
            document.getElementById("singlePriceError").textContent = "Single box price must be greater than 0.";
            valid = false;
        }
        if (wholePrice === "" || parseFloat(wholePrice) <= 0) {
            document.getElementById("wholePriceError").textContent = "Whole box price must be greater than 0.";
            valid = false;
        }
        if (images.length === 0) {
            document.getElementById("imageError").textContent = "At least one image is required.";
            valid = false;
        }

        return valid;
    }

    function previewImages() {
        let preview = document.getElementById("imagePreview");
        preview.innerHTML = "";
        let files = document.getElementById("images").files;
        Array.from(files).forEach(file => {
            let img = document.createElement("img");
            img.src = URL.createObjectURL(file);
            preview.appendChild(img);
        });
    }
</script>

</body>
</html>
