<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "assignment_db";

// Connect to the database
$conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if user_id is provided
if (!isset($_GET['user_id'])) {
    die("User ID not specified.");
}

$user_id = intval($_GET['user_id']);

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $full_name = trim($_POST['full_name']);
    $last_name = trim($_POST['last_name']);
    $address = trim($_POST['address']);

    $update_sql = "UPDATE users SET username=?, email=?, full_name=?, last_name=?, address=? WHERE user_id=?";
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param("sssssi", $username, $email, $full_name, $last_name, $address, $user_id);

    if ($stmt->execute()) {
        echo "<script>alert('Member updated successfully!'); window.location='mngMember.php';</script>";
    } else {
        echo "<script>alert('Failed to update member.');</script>";
    }
}

// Fetch member data
$sql = "SELECT * FROM users WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$member = $result->fetch_assoc();

if (!$member) {
    die("Member not found.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Update Member</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 30px;
            background-color: #f8f9fa;
        }
        .container {
            max-width: 600px;
            background: white;
            padding: 25px;
            border-radius: 10px;
            margin: auto;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
        }
        input[type="text"], input[type="email"] {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        button {
            margin-top: 20px;
            padding: 10px 20px;
            background: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background: #0056b3;
        }
        a {
            display: inline-block;
            margin-top: 15px;
            color: #007bff;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Update Member</h2>
    <form method="POST">
        <label>Username</label>
        <input type="text" name="username" value="<?php echo htmlspecialchars($member['username']); ?>" required>

        <label>Email</label>
        <input type="email" name="email" value="<?php echo htmlspecialchars($member['email']); ?>" required>

        <label>Full Name</label>
        <input type="text" name="full_name" value="<?php echo htmlspecialchars($member['full_name']); ?>" required>

        <label>Last Name</label>
        <input type="text" name="last_name" value="<?php echo htmlspecialchars($member['last_name']); ?>">

        <label>Address</label>
        <input type="text" name="address" value="<?php echo htmlspecialchars($member['address']); ?>">

        <button type="submit">Update Member</button>
        <br>
        <a href="mngMember.php">← Back to Manage Members</a>
    </form>
</div>

</body>
</html>

<?php
$conn->close();
?>
