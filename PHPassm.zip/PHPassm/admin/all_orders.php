<?php
session_start();
require '../assignment_db.php';

$search = isset($_GET['search']) ? trim($_GET['search']) : '';

$query = "
    SELECT o.*, COALESCE(GROUP_CONCAT(DISTINCT p.image SEPARATOR ','), '') AS product_images
    FROM orders o
    LEFT JOIN order_items oi ON o.order_id = oi.order_id
    LEFT JOIN products p ON oi.product_id = p.product_id
";

$params = [];  

if (!empty($search)) {
    $query .= " WHERE o.order_id LIKE ? OR o.user_id LIKE ? OR o.status LIKE ?";
    $params = ["%$search%", "%$search%", "%$search%"];
}

$query .= " GROUP BY o.order_id ORDER BY o.order_created_at DESC";


// Prepare and execute query
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Orders</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #ffe6f2;
            color: #333;
            margin: 0;
            padding: 20px;
            text-align: center;
        }
        h2 {
            text-align: center;
            color: #d63384;
        }

        table {
            width: 90%;
            margin: 20px auto;
            border-collapse: collapse;
            background: #fff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        th, td {
            padding: 12px;
            text-align: center;
            border-bottom: 1px solid #ddd;
            text-align: center;
        }
        th {
            background-color: #ff99cc;
            color: white;
        }
        tr:hover {
            background-color: #ffe6f2;
        }
        img {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 5px;
        }
        a {
            text-decoration: none;
            color: #d63384;
            font-weight: bold;
        }
        select, button, input[type="text"] {
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 5px;
            cursor: pointer;
        }
        select {
            background-color: #ffe6f2;
            color: #333;
        }
        button {
            background-color: #d63384;
            color: white;
            font-weight: bold;
        }
        button:hover {
            background-color: #b82f6b;
        }

    </style>
</head>
<body>

    <h2>All Orders</h2>
    <form method="GET">
        <input type="text" name="search" placeholder="Search User ID" value="<?= htmlspecialchars($search) ?>">
        <button type="submit">Search</button>
    </form>


    <table>
        <thead>
            <tr>
                <th>Order ID</th>
                <th>Product Images</th>
                <th>User ID</th>
                <th>Total Price (RM)</th>
                <th>Status</th>
                <th>Created At</th>
                <th>Details</th>
                <th>Update Status</th>
            </tr>
        </thead>
        <tbody id="orderTableBody">
            <?php if (count($orders) > 0): ?>
                <?php foreach ($orders as $order): ?>
                    <tr class="order-row">
                    <td class="order-id"><?= htmlspecialchars($order['order_id']) ?></td>
                        <td class="product-images">
                            <?php 
                            $images = explode(',', $order['product_images']);
                            foreach ($images as $image): 
                                if (!empty($image)): ?>
                                    <img src="uploads/<?= htmlspecialchars($image) ?>" alt="Product Image">
                                <?php else: ?>
                                    <span>No Image</span>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        </td>
                        <td class="user-id"><?= htmlspecialchars($order['user_id']) ?></td>
                        <td class="total-price">RM <?= htmlspecialchars(number_format($order['total_price'], 2)) ?></td>
                        <td class="order-status"><?= htmlspecialchars($order['status']) ?></td>
                        <td class="order-date"><?= htmlspecialchars($order['order_created_at']) ?></td>
                        <td><a href="order_details.php?order_id=<?= htmlspecialchars($order['order_id']) ?>">View</a></td>
                        <td>
                            <form action="update_order.php" method="post">
                                <input type="hidden" name="order_id" value="<?= htmlspecialchars($order['id']) ?>">
                                <select name="status">
                                    <option value="Pending" <?= ($order['status'] == 'Pending') ? 'selected' : '' ?>>Pending</option>
                                    <option value="Shipped" <?= ($order['status'] == 'Shipped') ? 'selected' : '' ?>>Shipped</option>
                                    <option value="Delivered" <?= ($order['status'] == 'Delivered') ? 'selected' : '' ?>>Delivered</option>
                                    <option value="Cancelled" <?= ($order['status'] == 'Cancelled') ? 'selected' : '' ?>>Cancelled</option>
                                </select>
                                <button type="submit">Update</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr id="noResults">
                    <td colspan="8">No orders found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <script>
    $(document).ready(function(){
        $("#orderSearch").on("keyup", function() {
            var value = $(this).val().toLowerCase();
            var hasResults = false;

            $(".order-row").each(function() {
                var rowText = $(this).text().toLowerCase();
                if (rowText.indexOf(value) > -1) {
                    $(this).show();
                    hasResults = true;
                } else {
                    $(this).hide();
                }
            });

            // Show "No orders found" message when no results match
            if (!hasResults) {
                $("#noResults").show();
            } else {
                $("#noResults").hide();
            }
        });
    });
    </script>

</body>
</html>
