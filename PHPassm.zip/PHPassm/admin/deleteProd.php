<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "assignment_db";

$conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['product_id'])) {
    $product_id = intval($_GET['product_id']);

    // Delete images first
    $delete_images = "DELETE FROM prod_details WHERE product_id = ?";
    $stmt = $conn->prepare($delete_images);
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $stmt->close();

    // Delete product
    $delete_product = "DELETE FROM products WHERE product_id = ?";
    $stmt = $conn->prepare($delete_product);
    $stmt->bind_param("i", $product_id);

    if ($stmt->execute()) {
        echo "Product deleted successfully!";
    } else {
        echo "Error deleting product.";
    }
    $stmt->close();
}

$conn->close();
?>
