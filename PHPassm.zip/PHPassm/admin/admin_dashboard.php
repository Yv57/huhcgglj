<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "assignment_db";

$conn = new mysqli($host, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch total products
$product_count_query = "SELECT COUNT(*) AS total FROM products";
$product_count_result = $conn->query($product_count_query);
$product_count = $product_count_result->fetch_assoc()['total'];

// Fetch total users
$user_count_query = "SELECT COUNT(*) AS total FROM users";
$user_count_result = $conn->query($user_count_query);
$user_count = $user_count_result->fetch_assoc()['total'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <style>
        /* Modern Light Theme */
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: #ffffff;
            color: #333;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            width: 80%;
            max-width: 600px;
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.1);
            text-align: center;
            border: 1px solid #ddd;
        }

        h2 {
            font-size: 26px;
            font-weight: 600;
            margin-bottom: 20px;
            color: #222;
        }

        .box {
            background: #f8f8f8;
            padding: 20px;
            border-radius: 10px;
            font-size: 20px;
            font-weight: bold;
            margin: 15px 0;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.08);
            transition: 0.3s;
        }

        .box:hover {
            transform: scale(1.05);
            background: #f0f0f0;
        }

        a {
            display: inline-block;
            margin-top: 15px;
            padding: 12px 20px;
            font-size: 18px;
            color: #fff;
            background: #000;
            border-radius: 8px;
            text-decoration: none;
            font-weight: bold;
            transition: 0.3s;
        }

        a:hover {
            background: #333;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Admin Dashboard</h2>
        <div class="box">Total Products: <?php echo $product_count; ?></div>
        <div class="box">Total Users: <?php echo $user_count; ?></div>
        <br>
        <a href="ProdManagement.php">Manage Products</a>
        <a href="mngMember.php">Manage Users</a>
    </div>
</body>
</html>

<?php $conn->close(); ?>
