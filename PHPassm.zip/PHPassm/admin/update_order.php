<?php
require '../assignment_db.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $order_id = $_POST['order_id'];
    $status = $_POST['status'];

    $stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?");
    $stmt->execute([$status, $order_id]);

    echo "Order updated successfully.";
}
?>

<form method="post">
    <input type="hidden" name="order_id" value="<?= $_GET['id'] ?>">
    <label>Update Status:</label>
    <select name="status">
        <option value="Pending">Pending</option>
        <option value="Shipped">Shipped</option>
        <option value="Delivered">Delivered</option>
        <option value="Cancelled">Cancelled</option>
    </select>
    <button type="submit">Update</button>
</form>
