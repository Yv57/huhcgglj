<?php
$host = "localhost";
$username = "root";
$password = "";
$database = "assignment_db";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all products
$sql = "SELECT p.product_id, p.name, p.description, p.price, p.stock
        FROM products p";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table border='1'>";
    echo "<tr><th>ID</th><th>Name</th><th>Description</th><th>Price</th><th>Stock</th><th>Images</th></tr>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($row['product_id']) . "</td>";
        echo "<td>" . htmlspecialchars($row['name']) . "</td>";
        echo "<td>" . nl2br(htmlspecialchars($row['description'])) . "</td>";
        echo "<td>RM " . number_format($row['price'], 2) . "</td>";
        echo "<td>" . htmlspecialchars($row['stock']) . "</td>";

        // Fetch all images for this product
        $product_id = $row['product_id'];
        $image_sql = "SELECT image FROM prod_details WHERE product_id = $product_id";
        $image_result = $conn->query($image_sql);

        echo "<td>";
        if ($image_result->num_rows > 0) {
            while ($image_row = $image_result->fetch_assoc()) {
                echo "<img src='data:image/jpeg;base64," . base64_encode($image_row['image']) . "' width='100' style='margin:5px;'>";
            }
        } else {
            echo "<img src='placeholder.jpg' width='100'>";
        }
        echo "</td>";

        echo "</tr>";
    }

    echo "</table>";
} else {
    echo "No products found.";
}

$conn->close();
?>
